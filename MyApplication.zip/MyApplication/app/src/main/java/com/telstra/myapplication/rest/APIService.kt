package com.example.retrofitlibrary.rest

import com.example.retrofitlibrary.model.QuestionList
import com.example.retrofitlibrary.model.User
import com.example.retrofitlibrary.model.UserResponse
import com.telstra.myapplication.model.Register
import com.telstra.myapplication.model.RegisterResponse
import retrofit2.Call
import retrofit2.http.*

interface APIService {
   // @GET("/2.2/questions?order=desc&sort=creation&site=stackoverflow")
   // fun fetchQuestions(@Query("tagged") tags: String): Call<QuestionList>


    @Headers("Accept: application/json","Auth: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImpvaG5AZG9lLmNvbSIsInVzZXJJZCI6IjYzMTVkMDllMzk1MmUwM2ZlYjM5YzllYyIsImlhdCI6MTY2MzU4MDIzMCwiZXhwIjoxNjYzNjY2NjMwfQ.GLxL7YAgFTKrlX0nCQ9gervagir8lC3-4DEVns1pL-Y")
    @POST("/signin")
    fun signIn(@Body user: User):Call<UserResponse>

    //@Headers("Accept: application/json","Auth: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImpvaG5AZG9lLmNvbSIsInVzZXJJZCI6IjYzMTVkMDllMzk1MmUwM2ZlYjM5YzllYyIsImlhdCI6MTY2MzU4MDIzMCwiZXhwIjoxNjYzNjY2NjMwfQ.GLxL7YAgFTKrlX0nCQ9gervagir8lC3-4DEVns1pL-Y")
   // @POST("/signup")
    //fun signUp(@Body register: Register):Call<RegisterResponse>

}
