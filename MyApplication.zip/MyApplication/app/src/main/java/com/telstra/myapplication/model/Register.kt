package com.telstra.myapplication.model

data class Register(
    val department: String,
    val email: String,
    val firstname: String,
    val lastname: String,
    val password: String,
    val userType: String
)