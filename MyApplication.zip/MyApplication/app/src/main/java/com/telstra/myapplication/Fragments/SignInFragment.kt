package com.telstra.myapplication.Fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.telstra.myapplication.AuthActivity
import com.telstra.myapplication.R
import com.telstra.myapplication.databinding.FragmentSigninBinding


class SignInFragment : Fragment() {

    companion object {
        const val ARG_NAME = "name"


        fun newInstance(name: String): SignInFragment {
            val fragment = SignInFragment()

            val bundle = Bundle().apply {
                putString(ARG_NAME, name)
            }

            fragment.arguments = bundle

            return fragment
        }
    }
    private var _binding: FragmentSigninBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(
            inflater: LayoutInflater, container: ViewGroup?,
            savedInstanceState: Bundle?
    ): View? {


        _binding = FragmentSigninBinding.inflate(inflater, container, false)
        return binding.root

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
       /* val activity: AuthActivity? = activity as AuthActivity?
        val myDataFromActivity: Boolean = activity!!.getloginstatus()
         if(myDataFromActivity) {*/
             binding.nextbutton.setOnClickListener {
                 findNavController().navigate(R.id.action_FirstFragment_to_myDashboardFragment2)

             }



        binding.ToRegisterFragmentbutton.setOnClickListener {
            findNavController().navigate(R.id.action_FirstFragment_to_SecondFragment)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}


