package com.example.retrofitlibrary.model

//This class maps the json keys to the object
class Question {

    val title: String? = null
    val link: String? = null
}
