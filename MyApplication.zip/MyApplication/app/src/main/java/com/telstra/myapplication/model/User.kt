package com.example.retrofitlibrary.model

data class User(
    val email: String,
    val password: String
)