package com.example.retrofitlibrary.model

data class UserX(
    val _id: String,
    val email: String,
    val firstName: String,
    val lastName: String,
    val userType: String
)