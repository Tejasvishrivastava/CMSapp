package com.telstra.myapplication.Fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import com.telstra.myapplication.AuthActivity
import com.telstra.myapplication.R
import com.telstra.myapplication.databinding.FragmentMyDashboardBinding
import com.telstra.myapplication.databinding.FragmentSelfSignedBinding


class MyDashboardFragment : Fragment() {

    private var _binding: FragmentMyDashboardBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentMyDashboardBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
       /* super.onViewCreated(view, savedInstanceState)
        val activity: AuthActivity? = activity as AuthActivity?
        val mytoken: String = activity!!.getusertoken()
        binding.userDetails.setText(mytoken)*/

        binding.selfsigned.setOnClickListener{
            /*val i = Intent(activity, MyDashboardActivity::class.java)
            startActivity(i)
            (activity as Activity?)!!.overridePendingTransition(0, 0)*/
            findNavController().navigate(R.id.action_myDashboardFragment2_to_selfSignedFragment)
        }

        binding.signed.setOnClickListener {
            findNavController().navigate(R.id.action_myDashboardFragment2_to_signedCertificateFragment)
        }
        binding.mycert.setOnClickListener{
            findNavController().navigate(R.id.action_myDashboardFragment2_to_cetificateitemFragment)
        }
        binding.casigned.setOnClickListener{
            findNavController().navigate(R.id.action_myDashboardFragment2_to_caSignedFragment2)
        }
        binding.logoutbutton.setOnClickListener{
            findNavController().navigate(R.id.action_myDashboardFragment2_to_FirstFragment)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
