package com.telstra.myapplication


import android.content.ContentValues.TAG
import android.content.SharedPreferences
import android.graphics.Color
import android.os.Bundle
import android.preference.PreferenceManager
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.NavDeepLinkBuilder
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupActionBarWithNavController
import com.example.retrofitlibrary.model.Question
import com.example.retrofitlibrary.model.User
import com.example.retrofitlibrary.model.UserResponse
import com.example.retrofitlibrary.rest.APIService
import com.example.retrofitlibrary.rest.RestClientHeroku
import com.telstra.myapplication.Fragments.SignInFragment
import com.telstra.myapplication.databinding.AuthActivityMainBinding
import com.telstra.myapplication.model.Register
import com.telstra.myapplication.model.RegisterResponse
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import com.telstra.myapplication.Fragments.RegisterFragment

class AuthActivity : AppCompatActivity() {

    private lateinit var tokenresult:String
    private  var loginSuccess:Boolean = false
    private lateinit var appBarConfiguration: AppBarConfiguration
    private lateinit var binding: AuthActivityMainBinding
   // private var mApiService: APIService? = null
    private var mApiServiceSignIn: APIService? = null
    private var mApiServiceSignUp :APIService? = null

    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var editor: SharedPreferences.Editor
    private lateinit var emailEditTextView: EditText
    private lateinit var passwordEditTextView: EditText
    private lateinit var loginbutton: Button
    private lateinit var proceedbutton: Button
    private lateinit var checkbox: CheckBox
    private lateinit var strPassword: String
    private lateinit var strEmail: String
    private lateinit var strCheckBox: String



    private lateinit var lastname : EditText
    private lateinit var firstname : EditText
    private lateinit var rpassword : EditText
    private lateinit var rusertype : EditText
    private lateinit var rdepartment : EditText
    private lateinit var remail : EditText
    private lateinit var registerButton : Button


/*    private var mAdapter: android.widget.ListAdapter?= null;
    private var mQuestions: MutableList<Question> = ArrayList()*/
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

            binding = AuthActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)

        val navController = findNavController(R.id.nav_host_fragment_content_main)
        appBarConfiguration = AppBarConfiguration(navController.graph)
        setupActionBarWithNavController(navController, appBarConfiguration)

           // mApiService = RestClient.client.create(APIService::class.java)
            mApiServiceSignIn= RestClientHeroku.client.create(APIService::class.java)
            mApiServiceSignUp= RestClientHeroku.client.create(APIService::class.java)
           /* listRecyclerView!!.layoutManager = LinearLayoutManager(this)

            mAdapter = ListAdapter(this, mQuestions, R.layout.question_item)
            listRecyclerView!!.adapter = mAdapter*/

        passwordEditTextView = findViewById<EditText>(R.id.passwordtext)
        emailEditTextView= findViewById<EditText>(R.id.emailtext)
        loginbutton = findViewById<Button>(R.id.Loginbutton)
        checkbox = findViewById<CheckBox>(R.id.checkBox)
        proceedbutton = findViewById<Button>(R.id.nextbutton)


  /*      //accesssing register resource file
        lastname = findViewById<EditText>(R.id.lastname)
        firstname = findViewById<EditText>(R.id.firstname)
        rpassword = findViewById<EditText>(R.id.Rpassowrd)
        remail = findViewById<EditText>(R.id.Remail)
        rusertype = findViewById<EditText>(R.id.Rusertype)
        rdepartment = findViewById<EditText>(R.id.Rdepartment)
        registerButton = findViewById<Button>(R.id.RegisterButton)

        registerButton.setOnClickListener() {
            signUp()
        }*/

        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this)
        editor = sharedPreferences.edit()
        checkSharedPreference()

        loginbutton.setOnClickListener() {

            signIn()


            if (checkbox.isChecked) {
                editor.putString(getString(R.string.checkBox), "True")
                editor.apply()
                strEmail = emailEditTextView.text.toString()
                editor.putString(getString(R.string.email), strEmail)
                editor.commit()
                strPassword = passwordEditTextView.text.toString()
                editor.putString(getString(R.string.password), strPassword)
                editor.commit()
            } else {
                editor.putString(getString(R.string.checkBox), "False")
                editor.commit()
                editor.putString(getString(R.string.email), "")
                editor.commit()
                editor.putString(getString(R.string.password), "")
                editor.commit()
                editor.putString(getusertoken(), "")
                editor.commit()
            }

    }

    }
//    fun getloginstatus():Boolean{
//       return loginSuccess
//    }
    fun getusertoken():String{
        return tokenresult
    }

    private fun checkSharedPreference() {
        strCheckBox = sharedPreferences.getString(getString(R.string.checkBox), "False").toString()
        strEmail = sharedPreferences.getString(getString(R.string.email), "").toString()
        strPassword = sharedPreferences.getString(getString(R.string.password), "").toString()
        emailEditTextView.setText(strEmail)
        passwordEditTextView.setText(strPassword)
        checkbox.isChecked = strCheckBox == "True"
    }

    private fun signIn() {
        val userMail = emailEditTextView.text.toString()
        val userPassword = passwordEditTextView.text.toString()
        val user= User(userMail,userPassword)
        //val token = UserResponse()
        val call = mApiServiceSignIn!!.signIn(user);
        call.enqueue(object : Callback<UserResponse> {

            override fun onResponse(call: Call<UserResponse>, response: Response<UserResponse>) {
                if(response.isSuccessful){

                    if(response.toString().contains("error")){
                        Toast.makeText(this@AuthActivity,"Invalid user",Toast.LENGTH_SHORT).show()
                        Log.e(TAG, "Error Response : $response")
                        return
                    }
                    else{
                        loginSuccess = true
                        tokenresult = response.body().toString().substringAfter("" +
                                "token=").substringBefore(',')
                        Toast.makeText(this@AuthActivity,"Logged In And your Token is $tokenresult  ",Toast.LENGTH_SHORT).show()

                        Log.d(TAG, "User Response: \"Logged In $tokenresult $loginSuccess\"  " + response.body()!!.user)

                        loginbutton.visibility = View.INVISIBLE
                        proceedbutton.visibility = View.VISIBLE
                    //  loginbutton.setBackgroundColor(Color.parseColor("#c72c2c"))
                       // loginbutton.setText("Proceed")
                       /* loginbutton.isEnabled = false
                        proceedbutton.isEnabled = true

                        */

                      /* setContentView(R.layout.fragment_my_dashboard)*/
                        /*val fragment = com.telstra.myapplication.Fragments.MyDashboardFragment()
                        val fram = supportFragmentManager.beginTransaction()
                        fram.replace(R.id.myDashboardFragment2,fragment)
                        fram.commit()*/
                    }
                }

            }

            override fun onFailure(call: Call<UserResponse>, t: Throwable) {
                Log.e(TAG, "Got error : " + t.localizedMessage)
                return
            }
        })
    }

/*    private fun signUp(){
        val registerLastName= lastname.text.toString()
        val registerPassword = rpassword.text.toString()
        val registerUserType = rusertype.text.toString()
        val registerFirstName = firstname.text.toString()
        val regitsterEmail = remail.text.toString()
        val registerDepartment = rdepartment.text.toString()
        val register= Register(registerDepartment,regitsterEmail,registerFirstName,registerLastName,registerPassword,registerUserType)
        //val token = UserResponse()
        val call = mApiServiceSignUp!!.signUp(register);
        call.enqueue(object : Callback<RegisterResponse> {

            override fun onResponse(call: Call<RegisterResponse>, response: Response<RegisterResponse>) {
                if(response.isSuccessful){

                    if(response.toString().contains("error")){
                        Toast.makeText(this@AuthActivity,"Invalid user",Toast.LENGTH_SHORT).show()
                        return
                    }
                    else{
                        Toast.makeText(this@AuthActivity,"Logged In",Toast.LENGTH_SHORT).show()

                        Log.d(TAG, "User Response: " + response.body().toString())
                    }
                }

            }

            override fun onFailure(call: Call<RegisterResponse>, t: Throwable) {
                Log.e(TAG, "Got error : " + t.localizedMessage)
                return
            }
        })
    }*/


    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        return when (item.itemId) {
            R.id.action_settings -> true
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        val navController = findNavController(R.id.nav_host_fragment_content_main)
        return navController.navigateUp(appBarConfiguration)
                || super.onSupportNavigateUp()
    }

}